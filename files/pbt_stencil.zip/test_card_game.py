from hypothesis import given, settings, strategies as st
from typing import Dict, Sequence
from card_game_utils import *
from correct_card_game import deal, draw, get_game_result

MAX_EXAMPLES = 1_000
settings.register_profile("student", settings(max_examples=MAX_EXAMPLES, deadline=None))
settings.load_profile("student")


def is_valid_deal(num_players: int, dealt_hands: Sequence[Hand]) -> bool:
    '''
    Property-check function for deal(num_players)

    Parameters:
        num_players: the number of hands to deal (input to deal)
        dealt_hands: the hands that were dealt (output from deal)
    
    Returns:
        True iff dealt_hands is valid according to the specification document
    '''
    # TODO: implement this function, replacing the "..."
    ...

def is_valid_draw(old_hand: Hand, num_to_draw: int, new_hand: Hand) -> bool:
    '''
    Property-check function for draw(old_hand, num_to_draw)

    Parameters:
        old_hand: the hand before drawing (input to draw)
        num_to_draw: the number of cards to draw (input to draw)
        new_hand: the hand after drawing (output from draw)

    Returns:
        True iff new_hand is valid according to the specification document
    '''
    # TODO: implement this function, replacing the "..."
    ...

def is_valid_get_game_result(player: Hand, opponent: Hand, result: GameResult) -> bool:
    '''
    Property-check function for get_game_result(player, opponent)
    
    Parameters:
        player: the player's hand (input to get_game_result)
        opponent: the opponent's hand (input to get_game_result)
        result: the result of the game (output from get_game_result)
        
    Returns:
        True iff result is valid according to the specification document
    '''
    # TODO: implement this function, replacing the "..."
    ...

# TODO: replace the "..." below with a valid Hypothesis strategy
num_players_strat = ...

@given(num_players=num_players_strat)
def test_deal(num_players: int):
    dealt_hands = deal(num_players)
    assert is_valid_deal(num_players, dealt_hands)

# TODO: replace the "..."s below with valid Hypothesis strategies
old_hand_strat = ...
num_to_draw_strat = ...

@given(old_hand=old_hand_strat, num_to_draw=num_to_draw_strat)
def test_draw(old_hand: Hand, num_to_draw: int):
    new_hand = draw(old_hand, num_to_draw)
    assert is_valid_draw(old_hand, num_to_draw, new_hand)

# TODO: replace the "..."s below with valid Hypothesis strategies
player_strat = ...
opponent_strat = ...

@given(player=player_strat, opponent=opponent_strat)
def test_get_game_result(player: Hand, opponent: Hand):
    result = get_game_result(player, opponent)
    assert is_valid_get_game_result(player, opponent, result)
    
    
if __name__ == '__main__':
    #### Include hand-written tests for is_valid_...() in this section


    #### End hand-written tests

    # test_deal()
    # test_draw()
    # test_get_game_result()
    print("done!")