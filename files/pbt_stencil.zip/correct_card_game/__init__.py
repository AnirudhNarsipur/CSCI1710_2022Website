from sys import version_info

if version_info < (3, 7):
    raise RuntimeError("Python 3.7 or later is required")
elif version_info.minor == 7:
    from correct_card_game.correct_card_game_cpython_37 import deal, draw, get_game_result
elif version_info.minor == 8:
    from correct_card_game.correct_card_game_cpython_38 import deal, draw, get_game_result
elif version_info.minor == 9:
    from correct_card_game.correct_card_game_cpython_39 import deal, draw, get_game_result
elif version_info.minor == 10:
    from correct_card_game.correct_card_game_cpython_310 import deal, draw, get_game_result
else:
    raise RuntimeError("Unsupported Python version")

__all__ = ["deal", "draw", "get_game_result"]